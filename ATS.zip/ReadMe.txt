1. Use a cmd terminal and create a python environment
	conda create -p venv python==3.10 -y

2.Activate the environment
	conda activate venv/
	activate venv/ (###Try this if you face errors###)

3.Install dependencies
	pip install -r requirements.txt

4. Run app.py using streamlit
	streamlit run app.py

